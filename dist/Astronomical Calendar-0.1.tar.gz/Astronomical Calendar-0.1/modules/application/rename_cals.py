from modules.adt import Calendar


for i in range(12, 24):
    cl = Calendar.create_from_file('data/newscalyear_ical({}).php'.
                                   format(str(i)))

    years = list(cl._years.keys())
    cl.write_to_file('data/ical_{}.php'.
                     format(str(years[1])))
